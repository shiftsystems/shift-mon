# Grafana Role.
Deploys Grafana as a part of the shift-mon role