# Victoriametrics Role.
Deploys Victoriametrics as a part of the shift-mon role