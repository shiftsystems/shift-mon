# Telegraf Role.
Deploys Telegraf as a part of the shift-mon role