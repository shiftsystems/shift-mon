
C:\users\Administrator\Documents\shift-rmm\telegraf.ps1 -telegraf_url "https://test.example.com" -telegraf-config-url "https://gitlab.com/shiftsystems/shift-rmm/-/raw/master/telegraf-configs/windows/telegraf.conf" -telegraf-org "shiftsystems" -telegraf-bucket "windows" -telegraf_version "1.15.2" -telegraf-token "GET_YOUR_OWN-TOKEN" 
