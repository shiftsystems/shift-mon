# Podman Role.
Deploys Podman as a part of the shift-mon role