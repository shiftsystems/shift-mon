#!/bin/bash
cd /opt/shift-mon
podman-compose down