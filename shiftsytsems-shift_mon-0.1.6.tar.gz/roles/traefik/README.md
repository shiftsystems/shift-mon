# Traefik Role.
Deploys Traefik as a part of the shift-mon role