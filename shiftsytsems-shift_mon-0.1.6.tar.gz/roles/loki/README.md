# Loki Role.
Deploys Loki as a part of the shift-mon role