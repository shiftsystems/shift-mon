# Uptime Kuma Role.
Deploys Uptime Kuma as a part of the shift-mon role