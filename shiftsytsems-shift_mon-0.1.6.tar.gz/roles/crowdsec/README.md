# Crowdsec Role.
Deploys Crowdsec as a part of the shift-mon role